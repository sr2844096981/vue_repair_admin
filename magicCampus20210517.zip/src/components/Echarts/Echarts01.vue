<template>
  <div>
    <div id="echarts01" style="width: 600px; height: 400px"></div>
  </div>
</template>

<script>
import * as echarts from "echarts";
export default {
  components: {},
  data() {
    return {};
  },
  mounted() {
    var chartDom = document.getElementById("echarts01");
    var myChart = echarts.init(chartDom);
    var option;
    option = {
      // 设置线条颜色
      //   color: ["#3F58FD"],
      // 图表标题
      //   title: {
      //     text: "",
      //   },
      // 图表提示框组件
      tooltip: {
        // 触发方式 坐标轴
        trigger: "axis",
        axisPointer: {
          type: "cross",
          label: {
            backgroundColor: "#6a7985",
          },
        },
      },
      // 图例组件
      // legend: {
      //     data: ['Line 3']
      // },
      // 工具箱组件 可以另存为图片
      // toolbox: {
      //     feature: {
      //         saveAsImage: {}
      //     }
      // },
      // 网格配置 可以控制图表大小
      grid: {
        left: "10px",
        right: "50px",
        top: "10px",
        bottom: "120px",
        containLabel: true,
      },
      // 设置x轴
      xAxis: [
        {
          type: "category",
          // 线条和坐标轴是否有缝隙
          boundaryGap: false,
          data: [
            "10.25",
            "10.27",
            "10.29",
            "10.31",
            "11.02",
            "11.04",
            "11.06",
            "11.08",
            "11.10",
            "11.12",
            "11.14",
            "11.25",
          ],
        },
      ],
      // 设置y轴
      yAxis: [
        {
          type: "value",
        },
      ],
      // 系列图表配置
      series: [
        {
          name: "浏览量",
          type: "line",
          smooth: true,
          //   单独修改线条样式
          lineStyle: {
            width: 2,
            color: ["#3F58FD"],
            opacity: .4
          },
          showSymbol: false,
          areaStyle: {
            opacity: 0.8,
            color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
              {
                offset: 0,
                color: "rgba(130,150,254)",
              },
              {
                offset: 1,
                color: "rgba(240,243,255)",
              },
            ]),
          },
          emphasis: {
            focus: "series",
          },
          data: [
            1200,
            1300,
            800,
            1100,
            1500,
            1200,
            2500,
            1100,
            1200,
            1300,
            1200,
            1100,
            1500,
          ],
        },
      ],
    };

    option && myChart.setOption(option);

    // 图表缩放
/*     window.addEventListener("resize",function(){
        myChart.resize();
    }) */
  },
  methods: {},
};
</script>

<style lang="css" scoped>
</style>
