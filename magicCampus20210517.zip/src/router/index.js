import Vue from 'vue'
import VueRouter from 'vue-router'

Vue.use(VueRouter)

const routes = [{
        path: '/',
        redirect: '/login'
    },
    {
        path: '/login',
        name: 'Login',
        component: () =>
            import ( /* webpackChunkName: "Login" */ '../views/Login/Login.vue')
    },
    {
        path: '/home',
        name: 'Home',
        component: () =>
            import ( /* webpackChunkName: "Home" */ '../viewsRepair/Home.vue'),
        children: [{
            path: '/index',
            component: () =>
                import ( /* webpackChunkName: "Index" */ '../viewsRepair/Index'),
        }, {
            path: '/notice',
            component: () =>
                import ( /* webpackChunkName: "Notice" */ '../viewsRepair/Notice'),
        }, {
            path: '/order',
            component: () =>
                import ( /* webpackChunkName: "Order" */ '../viewsRepair/Order'),
        }, {
            path: '/staff',
            component: () =>
                import ( /* webpackChunkName: "Staff" */ '../viewsRepair/Staff'),
        }, {
            path: '/showdata',
            component: () =>
                import ( /* webpackChunkName: "ShowData" */ '../viewsRepair/ShowData'),
        }, {
            path: '/amap',
            component: () =>
                import ( /* webpackChunkName: "BMapDemo" */ '../viewsRepair/AMapDemo'),
        }, {
            path: '/bmap',
            component: () =>
                import ( /* webpackChunkName: "BMapDemo" */ '../viewsRepair/BMapDemo'),
        }, {
            path: '/demo',
            component: () =>
                import ( /* webpackChunkName: "Demo" */ '../components/demo.vue'),
        }]
    },

]

const router = new VueRouter({
    routes
})


// 路由导航守卫
/* router.beforeEach((to, from, next) => {
    if (to.path === '/login') return next()
    const tokenStr = window.localStorage.getItem('token')
    if (!tokenStr) return next('/login')
    next()
}) */

export default router