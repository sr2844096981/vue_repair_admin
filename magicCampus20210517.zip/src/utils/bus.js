/* 
 * 兄弟组件传值公共bus
 */
import Vue from 'vue'
export default new Vue()