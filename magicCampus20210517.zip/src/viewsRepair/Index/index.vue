<template>
  <div>
    <!-- 页头 -->
    <div class="page-header">
      <i class="el-icon-s-home"></i>
      <span>首页</span>
    </div>
    <!-- 账号信息部分 -->
    <el-card shadow="never">
      <div class="userInfo">
        <div class="userAvatar">
          <el-avatar :size="50" :src="circleUrl"></el-avatar>
        </div>
        <ul class="infoItem1">
          <li>
            <span class="nickname">{{ userName }}</span>
            <i class="el-icon-edit"></i>
          </li>
          <li>
            <span>登录名：</span><span>{{ userId }}</span>
          </li>
          <li><span>账号状态：</span><el-tag size="small">启用</el-tag></li>
        </ul>

        <ul class="infoItem2">
          <li>当前合同数<span>22</span>项</li>
          <li><span>房源数777</span>比</li>
          <li>新增房源 <span>32</span> 家</li>
        </ul>
        <ul class="infoItem3">
          <li>
            <span class="icon"><i class="el-icon-s-cooperation"></i></span>
            <span class="title">卖家总数</span>
            <span class="number">456</span>
          </li>
          <li>
            <span class="icon"><i class="el-icon-s-opportunity"></i></span>
            <span class="title">浏览总数</span>
            <span class="number">999</span>
          </li>
          <li>
            <span class="icon"><i class="el-icon-s-flag"></i></span>
            <span class="title">目标客户</span>
            <span class="number">666</span>
          </li>
        </ul>
      </div>
    </el-card>
    <!-- 浏览分析图标部分 -->
    <div class="browse clearfix">
      <el-card class="box-card f-l" shadow="never">
        <div slot="header" class="clearfix">
          <span class="icon"><i class="el-icon-s-marketing"></i></span>
          <span>浏览统计分析</span>
        </div>
        <div class="eacharts-wrap"><Eacharts01 class="eachart" /></div>
      </el-card>
      <el-card class="box-card f-r" shadow="never">
        <div slot="header" class="clearfix">
          <span class="icon"><i class="el-icon-s-marketing"></i></span>
          <span>全天统计分析</span>
        </div>
        <div class="eacharts-wrap"><Eacharts02 class="eachart" /></div>
      </el-card>
    </div>
    <!-- 房源资讯 -->
    <el-card class="box-card house-news" shadow="never">
      <div slot="header" class="clearfix">
        <span class="icon"><i class="el-icon-s-order"></i></span>
        <span>房源资讯</span>
      </div>
      <div>
        <el-carousel indicator-position="outside">
          <el-carousel-item v-for="item in swiperImgUrl" :key="item.id">
            <img :src="item.url" alt="" />
          </el-carousel-item>
        </el-carousel>
      </div>
    </el-card>
  </div>
</template>
<script>
// 引入公共的bug，来做为中间传达的工具
import Bus from "@/utils/bus.js";
import Eacharts01 from "../../components/Echarts/Echarts01.vue";
import Eacharts02 from "../../components/Echarts/Echarts02.vue";
export default {
  name: "Index",
  components: { Eacharts01, Eacharts02 },
  data() {
    return {
      userId: "",
      circleUrl: "",
      userNumber: "",
      userName: "",
      swiperImgUrl: [
        {
          id: 1,
          url: "https://tinyurl.com/yf5f3l2n",
        },
        {
          id: 2,
          url: "https://tinyurl.com/yh9wgt67",
        },
        {
          id: 3,
          url: "https://tinyurl.com/yjxe9xxa",
        },
        {
          id: 4,
          url: "https://tinyurl.com/yhuohm7v",
        },
      ],
    };
  },
  mounted() {
    this.getUserInfo();
    this.watchCircleUrl();
  },
  methods: {
    // 获取localStorage中的userInfo
    getUserInfo() {
      let userInfo = JSON.parse(localStorage.getItem("userInfo"));
      this.circleUrl = userInfo.avatar;
      this.userName = userInfo.position;
      this.userId = userInfo.id;
      this.watchCircleUrl();
    },
    // 监听修改头像变化
    watchCircleUrl() {
      // 用$on事件来接收参数
      Bus.$on("circleUrl", (data) => {
        // 接收组件A传过来的数据
        this.circleUrl = data;
      });
    },
  },
  created() {},
  watch: {},
};
</script>

<style lang="css" scoped>
.userInfo {
  display: flex;
  padding: 20px;
}
.userAvatar {
  margin-top: 10px;
}
.infoItem1 {
  margin-left: 20px;
}
.infoItem1 .nickname {
  font-size: 14px;
  font-weight: 600;
}
.infoItem1 i {
  color: #f57d2d;
}
.infoItem1 li {
  margin-bottom: 5px;
}
.infoItem2 {
  flex: 1;
  margin-left: 80px;
}
.infoItem2 span {
  color: #f57d2d;
  font-weight: 600;
}
.infoItem2 li {
  margin-bottom: 5px;
}
.infoItem3 {
  display: flex;
  width: 400px;
  border-left: 3px dashed #ccc;
  padding: 0 30px 0 50px;
}
.infoItem3 li {
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-items: center;
  align-items: center;
}
.infoItem3 span {
  flex: 1;
  margin-bottom: 5px;
}
.infoItem3 .icon {
  display: block;
  width: 35px;
  height: 35px;
  background-color: #f0f2f7;
  border-radius: 100px;
  font-size: 22px;
  line-height: 35px;
  text-align: center;
  color: #3f58fd;
}

.infoItem3 .number {
  font-size: 14px;
  font-weight: 600;
  color: #3f58fd;
}

/* 浏览 */
.browse {
  margin-top: 20px;
}

.browse .box-card {
  width: 49.5%;
  height: 400px;
}

.browse .icon {
  display: inline-block;
  width: 35px;
  height: 35px;
  background-color: #f0f2f7;
  border-radius: 100px;
  font-size: 22px;
  line-height: 35px;
  text-align: center;
  color: #3f58fd;
  margin-right: 10px;
}

.eacharts-wrap {
  width: 100%;
  height: 100%;
}
.eacharts {
  width: 100%;
  height: 100%;
}
/* 房源资讯 */
.house-news {
  margin-top: 20px;
}

.house-news .icon {
  display: inline-block;
  width: 35px;
  height: 35px;
  background-color: #f0f2f7;
  border-radius: 100px;
  font-size: 22px;
  line-height: 35px;
  text-align: center;
  color: #3f58fd;
  margin-right: 10px;
}
.house-news img {
  width: 100%;
  height: 100%;
}
</style>
